<div>
	<h2>Credito registratie</h2>

	<h3>Hallo {{ $werknemer->naam }},</h3>
	<p>u heeft succesvol geregistreerd met de email: {{ $werknemer->email }}</p>
	<p>Bij de organsatie {{ $werknemer->organisatienaam }}</p>

</div>