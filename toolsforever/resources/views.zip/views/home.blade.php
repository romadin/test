<link rel="stylesheet" href="/css/home.css">
<body>
  <div id="wrapper" class="toggled">
    @include('gadget.header')

      <div class="container">
        <div class="row">
          <div class="col-md-12 main-content">
            <h1 class="display-3">Welkom</h1>
            <p>Wij zijn Tools For Ever, we hebben op dit moment 3 vestigingen in Almere, Rotterdam en eindhoven. 
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et odio tempore sapiente, nulla debitis ad voluptatum neque, laudantium libero ipsam possimus qui sint quo eveniet. Minus aliquid dignissimos, alias at?
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi quae omnis distinctio corporis ea expedita fugiat voluptatem maxime fuga pariatur, minima unde quas, recusandae accusantium vero, odit est quaerat delectus.</p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 image-zoom">
            <div class="image">
              <img src="/images/outsideOffice.png" alt="office">
            </div>
            <h2>Almere</h2>
          </div>
          <div class="col-md-4 image-zoom">
            <div class="image">
              <img src="/images/outsideOffice.png" alt="office">
            </div>
            <h2>Rotterdam</h2>
          </div>
          <div class="col-md-4 image-zoom">
            <div class="image">
              <img src="/images/outsideOffice.png" alt="office">
            </div>
            <h2>Eindhoven</h2>
          </div>        
        </div>
      </div>
  </div>
</body>
</html>